/*
 * McDUtils.java
 *
 * Created on June 28, 2007, 10:58 AM
 */

package com.fedex.chronos.irdt;

import java.util.HashMap;
import java.util.Vector;

/**
 *
 * @author 438901
 */
public class McDUtils {    

}
