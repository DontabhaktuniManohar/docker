#!/bin/sh

cd $SCRIPTS/rdt-batchservices

. $SCRIPTS/invadj-rdt-admin/stop_weblogic.sh admin

