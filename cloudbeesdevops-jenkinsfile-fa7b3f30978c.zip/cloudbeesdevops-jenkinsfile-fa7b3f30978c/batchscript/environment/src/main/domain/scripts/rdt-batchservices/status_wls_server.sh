#!/bin/sh

cd $SCRIPTS/rdt-batchservices

. $SCRIPTS/invadj-rdt-admin/status_weblogic.sh

