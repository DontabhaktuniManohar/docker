#!/bin/sh

${SCRIPTS}/invadj-rdt-admin/redeployApplication.sh rdtNewSvc
