#!/bin/ksh

cd $SCRIPTS/rdt-thinclient

. $SCRIPTS/invadj-rdt-admin/stop_weblogic.sh

