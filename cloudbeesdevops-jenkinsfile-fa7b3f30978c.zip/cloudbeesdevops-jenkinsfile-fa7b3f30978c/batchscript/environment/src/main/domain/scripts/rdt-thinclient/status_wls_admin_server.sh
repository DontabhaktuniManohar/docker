#!/bin/ksh

cd $SCRIPTS/rdt-thinclient

. $SCRIPTS/invadj-rdt-admin/status_weblogic.sh admin

