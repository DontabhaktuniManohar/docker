#!/bin/sh
#
# Script to source in the environment variables for RDT-INVADJ
#
#if [ -f $CFG/env/rdt.env ]
#then
#    . $CFG/env/rdt.env
#fi
echo
