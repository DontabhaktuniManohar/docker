#!/bin/sh
###################################################################
#
# PROJECT:      SRS-RDT-InvAdj
# APPLICATION:  WEBLOGIC - START SCRIPT
#
# DATE:         16-JAN-2015
#
###################################################################

cd $SCRIPTS/rdt-new-services

. $SCRIPTS/invadj-rdt-admin/status_weblogic.sh admin
