// node ('urh00614') {
// sh '''
// whoami
// echo "ssh-dss AAAAB3NzaC1kc3MAAACBAMF/NOOV3bBoku/pcBqC7hRKafCsTL0e6RLj4lrqK6uNxGkH9osHy5Xn8bTdBdSlBVppFc7CREZKz8+I/gNVG3v4XXVCi/k0MI6Ls9hE+bgNA3Crn7lxHLLGfLQSjE2BxBtzAhckXCkm+2u+mjjSCuyo53gqvKmH0AI8aA+zWtqxAAAAFQCJmbDEnTrot8eZM0qHpq6epASNsQAAAIEAsEbpsb/YfvzdBePCXVaArYLN1KpBrZUlzijrIZL9Gv86xPlcpfVuul2M2Uja9bgyKm2e5QmY8ID2SeutZ5Mbw0KYdsBB/bq7N/1mk7yvQh8lSu5efWRPWRgnLCuMWpKJuAnZVhw3xmQPmWJfkEc+UuQQkj80yMDqBq6UGbCtefAAAACAbObh6BbDcsdpM7TlHkywTdslkThD5yjDlHncf45pt692VhHhXbsbTx8UbrXn0F/sIIev6ZduX9bn9+DupegHtiKBMM/mRZv4Bd0uefdvupquGOho+fY15OFvMTMjZTZkWrbeDi+i4uWliLJtvUueNXVZCUMkh+leS7QF9jgmpwI= jenkins@uwb00078.ute.fedex.com" >> /opt/fedex/jenkins/.ssh/authorized_keys
// '''
// }

node ('uwb00078') {
sh '''
whoami
df -khP
ssh -T -i /opt/fedex/jenkins/.ssh/id_dsa -o StrictHostKeyChecking=no jenkins@urh00613.ute.fedex.com 'find /opt/fedex/jenkins/workspace/* -mtime +2  | xargs -i% rm -fr % '
ssh -T -i /opt/fedex/jenkins/.ssh/id_dsa -o StrictHostKeyChecking=no jenkins@urh00613.ute.fedex.com 'find /opt/fedex/jenkins/workspace/*\\@* -type d -maxdepth 0 |  xargs -i% rm -fr % '
ssh -T -i /opt/fedex/jenkins/.ssh/id_dsa -o StrictHostKeyChecking=no jenkins@urh00613.ute.fedex.com 'find /opt/fedex/jenkins/.m2/repository/* -mtime +2 |  xargs -i% rm -fr % '
df -khP
'''
}
