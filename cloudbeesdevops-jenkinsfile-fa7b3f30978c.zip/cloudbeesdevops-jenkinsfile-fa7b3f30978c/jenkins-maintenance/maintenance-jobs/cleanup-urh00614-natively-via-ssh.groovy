// node ('urh00614') {
node ('uwb00078') {
sh '''
whoami
df -khP
ssh -T -i /opt/fedex/jenkins/.ssh/id_dsa -o StrictHostKeyChecking=no jenkins@urh00614.ute.fedex.com 'find /opt/fedex/jenkins/workspace/* -mtime +2  | xargs -i% rm -fr % '
ssh -T -i /opt/fedex/jenkins/.ssh/id_dsa -o StrictHostKeyChecking=no jenkins@urh00614.ute.fedex.com 'find /opt/fedex/jenkins/workspace/*\\@* -type d -maxdepth 0 |  xargs -i% rm -fr % '
ssh -T -i /opt/fedex/jenkins/.ssh/id_dsa -o StrictHostKeyChecking=no jenkins@urh00614.ute.fedex.com 'find /opt/fedex/jenkins/.m2/repository/* -mtime +2 |  xargs -i% rm -fr % '

df -khP
'''
}
