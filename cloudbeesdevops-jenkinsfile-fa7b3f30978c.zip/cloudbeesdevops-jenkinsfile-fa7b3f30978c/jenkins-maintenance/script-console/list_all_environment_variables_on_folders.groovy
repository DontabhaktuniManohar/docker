import hudson.plugins.git.*
import jenkins.*
import jenkins.plugins.git.*
import jenkins.model.*
import java.lang.reflect.*
import org.jenkinsci.plugins.workflow.cps.*
import org.jenkinsci.plugins.workflow.libs.*

job_name_search = "3534"
property_name= "DIS"

Jenkins.instance.getAllItems(com.cloudbees.hudson.plugins.folder.AbstractFolder).each{ it->
  
  if (it.fullName.contains(job_name_search) && !it.fullName.contains("CICD") ) { //&& it.fullName.contains(job_name_search)) {
    
    env_var_folder = it.getProperties().getAll(com.cloudbees.hudson.plugins.folder.properties.EnvVarsFolderProperty.class)
    if (env_var_folder == null || env_var_folder.size() < 1) {
      return
    }
    
    
    env_var_libs = env_var_folder.get(0)
    if (env_var_libs != null) {
      //println(it.fullName)
      
      def myvar = env_var_libs.getClass().getDeclaredField('properties').get(env_var_libs).split("\n")
      myvar.each{ a ->
        if ((property_name != null || property_name != "") && a.contains(property_name)) {
	     println ( it.fullName + ":   " + a)
   		}
  	  }
    }
  }
} 





return null
