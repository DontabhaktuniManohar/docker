nojbs=0
noprj=0
Jenkins.instance.getAllItems(jenkins.branch.MultiBranchProject.class).each{ it->
  noprj += 1
}
    Jenkins.instance.getAllItems(org.jenkinsci.plugins.workflow.job.WorkflowJob.class).each {job ->
          if (!"${job}".contains("CleanUpJobs")) {
              //println job.definition
              nojbs += 1
          }
    }

println "Total projects : ${noprj}"
println "Total multibranch jobs : ${nojbs}"
