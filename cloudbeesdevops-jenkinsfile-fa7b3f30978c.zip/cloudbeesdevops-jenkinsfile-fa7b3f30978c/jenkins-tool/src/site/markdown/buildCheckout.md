
## buildCheckout ##
As of now no options - relies on the pipeline configuration of the Multi Branch Project.
