# groovy testing

```
$ groovy com/fedex/ci/TestDefinitions.groovy
```
