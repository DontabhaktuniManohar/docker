export https_proxy=http://internet.proxy.fedex.com:3128
export http_proxy=http://internet.proxy.fedex.com:3128
[[ -e /var/tmp/tools/report-parser.jar ]] && exit 0
[[ ! -e /var/tmp/tools/report-parser.jar ]] && curl -H "Accept-Encoding: gzip"  -o /var/tmp/tools/report-parser.jar -O https://nexus.prod.cloud.fedex.com:8443/nexus/repository/SEFS-6270-releases/com%2Ffedex%2Fcicd%2FReportsParser%2F1.0.5%2FReportsParser-1.0.5-jar-with-dependencies.jar
s
