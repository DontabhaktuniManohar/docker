
# teams-hook-definition-creator usage:

akaanfxg:resources ak751818$ python teams-hook-definition-creator.py  > teams-hook-definition-creator.json

and check in the teams-hook-definition-creator.json
