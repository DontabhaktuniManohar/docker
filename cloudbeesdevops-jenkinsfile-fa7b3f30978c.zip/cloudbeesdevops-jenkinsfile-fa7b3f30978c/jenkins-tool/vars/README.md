

gitlab admin function execution
```
JOB_URL=https://jenkins-shipment.web.fedex.com:8443/jenkins/job/ITINERARY-3534642/job/ITINERARY_PROXY_SERVICE_AUTOSTRADA/job/master/181 JOB_NAME=ITINERARY-3534642/ITINERARY_PROXY_SERVICE_AUTOSTRADA/master python gitlab_admin_functions.py git@gitlab.prod.fedex.com:APP3534642/itinerary-proxy-service.git  itinerary-proxy-service
```


Testing

python
```

```

groovy
```
$ groovy Definitions.groovy


$ vi buildSetup.groovy
import com.fedex.ci.*

// vars/buildPrepare.groovy
def call(Map config = [: ]) {
  ... pipeline code
}

static void main(String[] args) {
  Definitions d= new Definitions()
  // put your assertions / tests here
}
$ groovy buildSetup.groovy



```
