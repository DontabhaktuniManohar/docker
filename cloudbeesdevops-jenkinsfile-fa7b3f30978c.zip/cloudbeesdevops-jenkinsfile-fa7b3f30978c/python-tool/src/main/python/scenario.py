from fdeploy.platform.airflow import login_dag
import sys

login_dag.Main(sys.argv[1:])
