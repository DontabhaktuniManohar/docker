log_debug "starting batch execution - ${local_base_dir}/master-${_uuid}.sh"
. ${local_base_dir}/master-${_uuid}.sh
log_info "completed"
# ---- end - master_execute.sh - source
