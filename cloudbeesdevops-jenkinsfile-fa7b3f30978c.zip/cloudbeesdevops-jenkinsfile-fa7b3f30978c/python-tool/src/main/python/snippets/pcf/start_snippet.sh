cf start ${APP_NM}
