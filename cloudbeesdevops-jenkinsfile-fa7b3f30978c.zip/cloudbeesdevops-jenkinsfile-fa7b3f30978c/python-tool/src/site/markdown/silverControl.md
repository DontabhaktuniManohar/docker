## silverControl ##

   
The silverControl is a tool for automating interaction with TIBCO Silver Fabric

usage: `python silverControl `



